#include "TM4C123GH6PM.h"

uint32_t ASCII_To_Hex(uint32_t in);
uint32_t Hex_To_ASCII(uint32_t in);
