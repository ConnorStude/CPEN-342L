#include "TM4C123GH6PM.h"

void DIP_Init(void);
uint32_t DIP_Read(void);
