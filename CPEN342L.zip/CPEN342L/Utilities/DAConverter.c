/****************************************************************************
Author: Matthew VonWahlde
Lab 9: D/A Applications
Date Created: March 29, 2023
Last Modified:
Description: Driver code for the Digital to Analog Converter
Inputs: None
Outputs: SSI through PD0, PD1, and PD3
****************************************************************************/

#include "DAConverter.h"

/*
Function: SSI1DAC_Init()
Inputs: None
Outputs: None
Description: Initializes SSI1 for use in DA converter
*/
void SSI1DAC_Init(void) {
	SYSCTL->RCGCSSI |= 2; // enable clock to SSI1
	SYSCTL->RCGCGPIO |= 0x08; // enable clock to GPIOF for SSI1
	while((SYSCTL->PRGPIO&0x08) == 0) {}; // ready?
	GPIOD->DEN |= 0x0B; // 
	GPIOD->AFSEL |= 0x09; // enable alternate function for pin1,2
	GPIOD->PCTL &= ~0x0000F00F; // assign pins to SSI1
	GPIOD->PCTL |= 0x00002002; // assign pins to SSI1
	GPIOD->DIR |= 0x02; // set pin 1 as output
	SSI1->CR1 = 0; // disable SSI and make it master
	SSI1->CPSR = 10; // prescaler divided by 10
	SSI1->CR0 = 0x0047; // 5 MHz SSI clock, SPI mode, 8 bit data
	SSI1->CR1 |= 2; // enable SSI1
}


/*
Function: SSI1DAC_Write()
Inputs: unsigned char - data to write
Outputs: None
Description: Writes 8 bits of data to the DAC through SSI1
*/
void SSI1DAC_Write(unsigned char data) {
while((SSI1->SR & 2) == 0) {}; // wait until FIFO not full
SSI1->DR = data; // transmit high byte
while(SSI1->SR & 0x10); // wait until transmit complete
}


/*
Function: hex2bcd()
Inputs: unsigned char - data to convert to bcd, char* - string to write to LCD
Outputs: None
Description: Writes the inputted voltage values in a string that can be displayed
*/
void hex2bcd(unsigned char data, char* str){
	// holds the 2 bcd digits
	unsigned int bcd[2];
	
	// Since our values are 0-15, if it's bigger than 9,
	//   the ten's digit is a 1
	if(data > 9){
		bcd[0] = 1;
		data -= 10;
	}else
		bcd[0] = 0;
	
	// The one's digit is the remaining value for data 
	bcd[1] = data;
	
	// Convert to ASCII by adding 48 and store in string to write to LCD
	str[0] = bcd[0] + 48;
	str[1] = bcd[1] + 48;
}
