#include "Hex_ASCII_Conversion.h"


//takes character and converts to hexidecimal
//only CAPS are allowed for letters
//returns 10 if out of range
uint32_t ASCII_To_Hex(uint32_t in)
{
	if ((in >= 65) && (in <=70))
	{
		return (in-55);
	}
	else if ((in >=48)&&(in<=57))
	{
		return (in-48);
	}
	else
	{
		return 0x10;
	}
}

//takes hexidecimal and converts to an ascii char
//only CAPS are allowed for letters
//returns 10 if out of range
uint32_t Hex_To_ASCII(uint32_t in)
{
	if ((in >= 0x0A) & (in <=0xF))
	{
		return (in+55);
	}
	else if ((in<=0x09)&&(in >=0x00))
	{
		return (in+48);
	}
	else
	{
		return 0x10;
	}
}
