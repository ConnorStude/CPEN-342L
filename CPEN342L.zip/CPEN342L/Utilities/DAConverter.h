/****************************************************************************
Author: Matthew VonWahlde
Lab 9: D/A Applications
Date Created: March 29, 2023
Last Modified:
Description: Header file for driver for the Digital to Analog Converter
Inputs: None
Outputs: SSI through PD0, PD1, and PD3
****************************************************************************/

#include "TM4C123GH6PM.h"

void SSI1DAC_Init(void);
void SSI1DAC_Write(unsigned char);
void hex2bcd(unsigned char, char*);
