#include "TM4C123GH6PM.h"

void BarLED_Init(void);
void displayLED(uint32_t inData);
