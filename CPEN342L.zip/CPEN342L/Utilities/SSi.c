#include "TM4C123GH6PM.h"
#include "SSI.h"

//switches and LEDs are interfaced to SSI1 (PD0-3)
void SSI1_Init(void){
	SYSCTL->RCGCSSI |= 0x02; //Activate SSI0 - bit 0 for SSI0, 1 for SSI1 �
	SYSCTL->RCGCGPIO |= 0x08; /* enable clock to Port D */
	while((SYSCTL->PRGPIO&0x08) == 0) {}; // ready?
	GPIOD->AFSEL |= 0x0F; /* enable alternate function on PD0~PD3*/
	GPIOD->PCTL = (GPIOD->PCTL&0xFFFF0000)+0x00002222;
	GPIOD->AMSEL &= ~0x0F; /* disable analog for these pins */
	GPIOD->DEN |= 0x0F; /* enable digital I/O on PD~0123 */
	SSI1->CR1 = 0x00; /* disable SSI and make it master */
	SSI1->CPSR = 0x0A; /* 8MHz SSICLK; assume system clock 16MHz */
	SSI1->CR0 &= ~(0x0000FFF0); // SSI, SPO = 0, SPH = 0; SCR=0
	SSI1->CR0 = (SSI1->CR0 &~0x0F) + 0x07; /* 8 bit data */
	SSI1->CR1 |= 0x02; /* enable SSI1 */
		
}

//PE3 and PD1 latch the data for 74HC595 and 
//load || input for 74HC165
void PortE_Init(void){
	SYSCTL->RCGCGPIO |= 0x10;   // enable clock to GPIOE
	while((SYSCTL->PRGPIO&0x10) == 0){};// ready?
	GPIOE->DIR |= 0x08;         // PORTA 3 as GPIO output pins
  GPIOE->DEN |= 0x08; 
}

//74HC595 (output)
void Port_Out(uint8_t code){
	while((SSI1->SR&0x02)==0){}; //wait until room in FIFO
	SSI1->DR = code; //data out
	while(SSI1->SR & 0x10) {}; 
}
//74HC165 (input)  
unsigned char SSI1_Read(void)
{
	while((SSI1->SR & 0x01) == 0) {};/* wait until FIFO empty */
	GPIOE->DATA &= ~0x08;
	delayMs(10); //delay 10 ms
	GPIOE->DATA |= 0x08;
	SSI1->DR = 0; /* trigger 8 SCK pulses to shift in data */
	
	while((SSI1->SR & 0x04) == 0) {}; /* wait until FIFO not empty */
	return SSI1->DR;
}

void delayMs(int n) {
    int i, j;
    for(i = 0 ; i< n; i++)
        for(j = 0; j < 6265; j++)
            {}  /* do nothing for 1 ms */
}