#include "BarLED.h"


//Initialization of PORTF for the barLED
void BarLED_Init(void)
{
	SYSCTL->RCGCGPIO |= 0x20;
	while((SYSCTL->PRGPIO&0x20)==0){};
	GPIOF->LOCK = 0x4C4F434B;
	GPIOF->CR |= 0xFF;
	GPIOF->PCTL &= ~0x0FFFF0;
	GPIOF->AFSEL &= ~0x1E;
	GPIOF->AMSEL &= ~0x1E;
	GPIOF->DIR |= 0x1E;
	GPIOF->DEN |= 0x1E;
}

//Inputs: integer or Char
//Outputs: Binary Data to Bar LED
void displayLED(uint32_t inData)
{
	inData = inData <<1; //align the bits
	GPIOF->DATA &= ~0x1E;
	GPIOF->DATA |= inData;
}
