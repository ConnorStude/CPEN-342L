#include "TrafficLights.h"


void TrafficLights_Init(void)
{
	SYSCTL->RCGCGPIO |= 0x02;
	while((SYSCTL->PRGPIO&0x02)==0){};
	GPIOB->AFSEL &= ~0x0F;
	GPIOB->AMSEL &= ~0x0F;
	GPIOB->PCTL &= ~0x0FFFF;
	GPIOB->DIR |= 0x3F;
	GPIOB->DEN |= 0x3F;
}