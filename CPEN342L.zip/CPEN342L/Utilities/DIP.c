#include "DIP.h"

//initialize DIP switch
void DIP_Init(void)
{
	SYSCTL->RCGCGPIO |= 0x02;
	while((SYSCTL->PRGPIO&0x02)==0){};
	GPIOB->AFSEL &= ~0x0F;
	GPIOB->AMSEL &= ~0x0F;
	GPIOB->PCTL &= ~0x0FFFF;
	GPIOB->DIR &= 0xF0;
	GPIOB->DEN |= 0x0F;
}

//Will read the DIP switch and return 
//an unsigned 8 bit integer representing
//the value of the switches 
uint32_t DIP_Read(void)
{
	uint32_t data = GPIOB->DATA;
	data &= 0x0F;
	return (data);
}
