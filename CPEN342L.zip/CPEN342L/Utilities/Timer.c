#include "Timer.h"

int Timer0Time; int Timer1Time; int TimeDifference;

void Timer_Init(void) {
    SYSCTL->RCGCTIMER |= 0x01; // enable Timer 0 clock
    SYSCTL->RCGCGPIO |= 0x2; // enable GPIO Port B clock
    GPIOB->AFSEL |= 0x50; // enable alternate function for PB4 and PB6
    GPIOB->PCTL = (GPIOB->PCTL&0xF0F0FFFF)+0x07070000;
    GPIOB->DEN |= 0x50; // enable digital I/O on PF4
    
    TIMER0->CTL &= ~0x01; // disable Timer 0A during setup
    TIMER0->CFG = 0x04; // configure for 16-bit mode
    TIMER0->TAMR = 0x07; // configure for capture mode
    TIMER0->IMR = 0x04; // Timer 0A capture interrupt enabled
    TIMER0->TAILR = 0x0000FFFF; // start value
    TIMER0->TAPR = 0xFF;

    TIMER1->CTL &= ~0x01; // disable Timer 1A during setup
    TIMER1->CFG = 0x04; // configure for 16-bit mode
    TIMER1->TAMR = 0x07; // configure for capture mode
    TIMER1->IMR = 0x04; // Timer 0A capture interrupt enabled
    TIMER1->TAILR = 0x0000FFFF; // start value
    TIMER1->TAPR = 0xFF;

    NVIC->PRI4 = (NVIC->PRI4 & 0x00FFFFFF) | 0x80000000; // set interrupt priority to 4
    NVIC->PRI5 = (NVIC->PRI5 & 0xFFF0FFFF) | 0x00080000; // set interrupt priority to 4
    NVIC->EN0 = 0x00000002; // enable interrupt on F in NVIC
    TIMER0->CTL = 0x00000001; // enable Timer 0A
    TIMER1->CTL = 0x00000001; // enable Timer 0A

    NVIC->IP[19] = 2 << 5; // 19: IRQ number; 2: priority; 5: fixed-shift 5 position
    NVIC->ISER[0] = 1<<19; // enable interrupt 19 in NVIC
    __enable_irq(); /* global enable IRQs */
}

void TIMER0A_Handler(void)
{
    TIMER0->ICR = 0x00000004; // ack timer0A
    GPIOF->DATA ^= 0x02;
    Timer0Time = TIMER0->TAR;
}

void TIMER1A_Handler(void)
{
    TIMER1->ICR = 0x00000004; // ack timer0A
    GPIOF->DATA ^= 0x02;
    Timer1Time = TIMER1->TAR;
    TimeDifference = Timer1Time - Timer0Time;
}
