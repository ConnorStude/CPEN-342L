#include "TM4C123GH6PM.h"
#include "Timer.h"
#include "LCD.h"

int main()
{
    int ClockSpeed = 20; //20 nanoseconds?
    SwitchInit();
    Timer_Init();
    LED_Init();
    while(1)
    {
        LCD->displayLED((extern TimeDifference)*ClockSpeed/1000000000); 
        //convert clock cycles
    };

    return 0;
}