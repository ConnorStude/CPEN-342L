void TrafficLights_Init(void);
