#include "TM4C123GH6PM.h"
#include "SysTick.h"


volatile uint32_t count = 0;



void PLL_Init(void) {
	SYSCTL->RCC2 |= 0x80000000; // 0) Use RCC2
	SYSCTL->RCC2 |= 0x00000800; // 1) bypass PLL while initializing
	SYSCTL->RCC = (SYSCTL->RCC&~0x000007C0)+0x00000540; //2)16 MHz
	SYSCTL->RCC2 &= ~0x00000070; // configure for main oscillator source
	SYSCTL->RCC2 &= ~0x00002000; // 3) activate PLL by clearing PWRDN
	SYSCTL->RCC2 |= 0x40000000; // 4) use 400 MHz PLL
	SYSCTL->RCC2 = (SYSCTL->RCC2&~0x1FC00000) + (0x27<<22); // 10 MHz
	while((SYSCTL->RIS&0x00000040) == 0) {}; // 5) wait for the PLL to lock
	SYSCTL->RCC2 &= ~0x00000800; // 6) enable PLL by clearing BYPASS
}


void SysTick_Init(uint32_t period){
SysTick->CTRL = 0; // 1) disable SysTick during setup
SysTick->LOAD = period -1; // 2) reload value
SysTick->VAL = 0; // 3) any write to CURRENT clears it
SysTick->CTRL = 0x00000007; // 4) enable SysTick with core clock and
//interrupts (local)
__enable_irq(); // enable interrupts (global)
}

void SysTick_Handler(void){
	if (count < 10){
		GPIOB->DATA = ~0x21;
		count++;
	}
	else if (count < 12){
		GPIOB->DATA = ~0x11;
		count++;
	}
	else if (count < 13){
		GPIOB->DATA = ~0x09;
		count++;
	}
	else if (count < 23){
		GPIOB->DATA = ~0x0C;
		count++;
	}
	else if (count < 25){
		GPIOB->DATA = ~0x0A;
		count++;
	}
	else if (count < 26){
		GPIOB->DATA = ~0x09;
		count = 0;
	}
}
