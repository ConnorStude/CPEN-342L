#include "TM4C123GH6PM.h"
#include "SysTick.h"
#include "TrafficLights.h"



int main (void){
	TrafficLights_Init();
	GPIOB->DATA |= 0x3F;
	SysTick_Init(100000000);
	while(1){};	
}

