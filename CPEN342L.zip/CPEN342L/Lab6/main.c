#include "TM4C123GH6PM.h"

void SSI_Init(void);
uint8_t SSI_Read(void);
void SSI_Write(uint16_t code);

int main (void){
	SSI_Init();
	while(1){
		SSI_Write(0x66);
	}
}
void SSI_Init(void)
{
    SYSCTL->RCGCSSI |= 0x02; // activate SSI2
    SYSCTL->RCGCGPIO |= 0x18; // activate port B
    while((SYSCTL->PRGPIO&0x18) == 0){};// ready?
    GPIOD->AFSEL |= 0x0F; // enable alt funct on PB4,5,6,7
    GPIOD->PCTL = (GPIOD->PCTL&0xFFFF0000)|0x00002222;
		GPIOE->DEN |= 0x08;
		GPIOE->DIR |= 0x08;
		GPIOE->DATA |= 0x08;
    GPIOD->AMSEL = 0; // disable analog`  functionality on PB
    GPIOD->DEN |= 0x0F; // enable digital I/O on PB4-7
		//SSI1->CR1 = 0x00;
    SSI1->CR1 &= ~0x02; // disable SSI2
    SSI1->CR1 &= ~0x04; // master mode (default setting)
		//SSI2->CC = 0x00;
    SSI1->CPSR = 0x0A; // 5 MHz SSIClk
		SSI1->CR0 &= ~(0x0000FFF0);
    SSI1->CR0 &= (SSI1->CR0 & ~0x0F) | 0x07; // SPO=SPH=0 SCR = 0
    //SSI2->CR0 |= 0x00; //Freescale
    //SSI2->CR0 |= 0x08;// 8-bit data
    SSI1->CR1 |= 0x02; // enable SSI2
}

void SSI_Write(uint16_t code)
{
    while((SSI1->SR & 2) == 0) {}; /* wait until FIFO not full */
		SSI1->DR = code; 						/* transmit a byte */
		while(SSI1->SR & 0x10) {}; 		/* wait until transmit complete */          // acknowledge response
}

uint8_t SSI_Read(void)
{
    while((SSI2->SR & 0x01) == 0) {};/* wait until FIFO empty */
		SSI2->DR = 0; /* trigger 8 SCK pulses to shift in data */
		while((SSI2->SR & 0x04) == 0) {}; /* wait until FIFO not empty */
		return SSI2->DR;
}
