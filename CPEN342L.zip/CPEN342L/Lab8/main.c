#include "TM4C123GH6PM.h�

void PWM_Duty(uint16_t high);
void PWM_Init(uint16_t period, uint16_t high);

void PWM_Init(uint16_t period, uint16_t high){
SYSCTL->RCGCTIMER |= 0x01; // activate timer0
SYSCTL->RCGCGPIO |= 0x0002; // activate port B
while((SYSCTL->PRGPIO&0x0002) == 0){};// ready?
GPIOB->AFSEL |= 0x40; // enable alt funct on PB6
GPIOB->DEN |= 0x40; // enable digital I/O on PB6
GPIOB->PCTL = (GPIOB->PCTL&0xF0FFFFFF)+0x07000000;
TIMER0->CTL &= ~0x00000001; // disable timer0A during setup
TIMER0->CFG = 0x00000004; // configure for 16-bit timer mode
TIMER0->TAMR = 0x0000000A; // PWM and periodic mode
TIMER0->TAILR = period-1; // timer start value
TIMER0->TAMATCHR = period-high-1; // duty cycle = high/period
TIMER0->CTL |= 0x00000001; // enable timer0A 16-bit, PWM
}

// duty cycle = high/period
void PWM_Duty(uint16_t high){
TIMER0->TAMATCHR = TIMER0->TAILR-high;
}
// Assume bus clock is 50 MHz
int main(void) {
PWM_Init(50000, 30000); // 1 KHz, duty cycle 60%
PWM_Duty(10000); // duty cycle 20%
while(1);
}