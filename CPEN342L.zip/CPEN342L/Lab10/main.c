#include "TM4C123GH6PM.h"
#include "DAConverter.h"
#include "LCD.h"
#include "delay.h"

int main (void)
{
	SSI1DAC_Init();
	unsigned int value = 0;
	volatile unsigned char highDgt=0, lowDgt=0;
	while(1)
	{
			while ((GPIOF->DATA &0x10) !=0{}; // wait for SW1 to be pressed
				
				
		
			for (int i = 0; i<4096; i++){
			value = i;
			GPIOD->DATA |= 0x02;
			GPIOD->DATA &= ~0x02;
			lowDgt = (unsigned char)value;
			highDgt = (unsigned char)(value>>8);
			SSI1DAC_Write(highDgt);
			SSI1DAC_Write(lowDgt); 
				if(GPIOA->DATA &0x80)==0)
					break;
			}
			double resistance = 250;
			double volt = (4096/value)*5;
			double amps = volt/resistance;
			double rx = 2/amps;
			
			char str[15];
			LCD_command(1);
			sprintf(str,"%d oms", rx),
			LCD_Str(str);
}
}
void PF4Pa7_init(void)
{
	SYSCTL->RCGCPIO |= 0x21;
	GPIOA->DIR &~0x80;
	GPIOF->DIR &= ~0x10;
	GPIOA->DEN |=0x80;
	GPIOF->DEN |= 0x10;
	GPIOA->DATA |=0x80;
}
