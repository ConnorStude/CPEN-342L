#include "TM4C123GH6PM.h"
#include "delay.h"

void MatrixLEDPortsInit(void);
void DIPToMatrixLED(char c);
int main (void){
	MatrixLEDPortsInit();
	while(1){
	GPIOF->DATA &= ~0x1E;
	GPIOD->DATA &= ~0x40;
	GPIOD->DATA |= 0x07;
	DIPToMatrixLED(0xF7);
	}
	/*while(1){
	GPIOF->DATA &= ~0x1E;
	GPIOD->DATA &= ~0x40;
	delayMs(1);
	GPIOF->DATA |= 0x02;
	GPIOD->DATA &= ~0x07;
		delayMs(1);
	//GPIOD->DATA &= ~0x07;
		
	GPIOF->DATA &= ~0x1E;
	delayMs(1);
	GPIOF->DATA |= 0x04;
	GPIOD->DATA &= ~0x07;
	
	delayMs(1);
		
	GPIOF->DATA &= ~0x1E;
	delayMs(1);
	GPIOF->DATA |= 0x08;
	GPIOD->DATA &= ~0x07;
		
	delayMs(1);
		
	GPIOF->DATA &= ~0x1E;
	delayMs(1);
	GPIOF->DATA |= 0x10;
	GPIOD->DATA &= ~0x07;
	delayMs(1);
	
	GPIOF->DATA &= ~0x1E;
	GPIOD->DATA |= 0x40;
	GPIOD->DATA &= ~0x07;
	delayMs(1);
	GPIOD->DATA &= ~0x40;
	
	delayMs(1);
	}*/
}
void MatrixLEDPortsInit(void)
{
		SYSCTL->RCGCGPIO |= 0x28;   // enable clock to GPIOD and GPIOF
		while((SYSCTL->PRGPIO&0x28) != 0x28){};
    // PORTF 1-4
    GPIOF->AMSEL &= ~0x1E;// 
    GPIOF->DIR |= 0x1E;         //
    GPIOF->DEN |= 0x1E;         // 
		//GPIOF->DATA &= ~0x1E;
    // PORTD 0-3
			GPIOD->AMSEL &= ~0x47;      // disable analog
    GPIOD->DIR |= 0x47;         // 
    GPIOD->DEN |= 0x47;  
			/*
		GPIOD->AMSEL &= ~0x0F;      // disable analog
    GPIOD->DIR |= 0x0F;         // 
    GPIOD->DEN |= 0x0F;         // 
		//GPIOD->DATA &= ~0x07;*/
}

unsigned char num[16][5]={ 
//left to right
{0xF7, 0xED, 0xDD, 0xBD, 0x7F}, // �0�  
{0xF1, 0xE9, 0xD9, 0xB9, 0x79}, // �1�
{0xF7, 0xE9, 0xDF, 0xBC, 0x7F}, // �2�
{0xF7, 0xE9, 0xDF, 0xB1, 0x7F}, // �3� 
{0xF5, 0xED, 0xDF, 0xB9, 0x79}, // �4�
{0xF7, 0xEC, 0xDF, 0xB9, 0x7F}, // �5�
{0xF7, 0xEC, 0xDF, 0xBD, 0x7F}, // �6�
{0xF7, 0xE9, 0xD9, 0xB9, 0x79}, // �7�
{0xF7, 0xED, 0xDF, 0xBD, 0x7F}, // �8�
{0xF7, 0xED, 0xDF, 0xB9, 0x79}, // �9�
{0xF7, 0xED, 0xDF, 0xBD, 0x7D}, // �A�
{0xF4, 0xEC, 0xDF, 0xBD, 0x7F}, // �B�
{0xF7, 0xEC, 0xDC, 0xBC, 0x7F}, // �C�
{0xF1, 0xE9, 0xDF, 0xBD, 0x7F}, // �D�
{0xF7, 0xEC, 0xDF, 0xBC, 0x7F}, // �E�
{0xF7, 0xEC, 0xDF, 0xBC, 0x7C}  // �F�

};

void DIPToMatrixLED(char c){
	int PD02,PF14,PD6;
	PD02 = (c & 0x07);
	PF14 = (c & 0xF0);
	PD6 = (c & 0x08);
	PD6 = (PD6 <<  3);
	PF14 = (PF14 >> 3);
	GPIOF->DATA &= ~0x1E;
	GPIOD->DATA &= ~0x40;
	GPIOD->DATA |= 0x07;
	delayMs(1);
	GPIOF->DATA &= ~PF14;
	delayMs(1);
	GPIOD->DATA &= ~PD02;
	delayMs(1);
	GPIOD->DATA &= ~PD6;
	//GPIOD->DATA |= PD6;
	delayMs(1);
	
}

