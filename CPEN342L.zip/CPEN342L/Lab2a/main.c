#include "TM4C123GH6PM.h"
#define RS 1    // BIT0 mask for reg select
#define EN 2    // BIT1 mask for E

void LCD_init(void) {
    PORTS_init();
    delayMs(20);                // LCD controller reset sequence
    LCD_nibble_write(0x30, 0);
    delayMs(5);
    LCD_nibble_write(0x30, 0);
    delayMs(1);
    LCD_nibble_write(0x30, 0);
    delayMs(1);

    LCD_nibble_write(0x20, 0);  // use 4-bit data mode
    delayMs(1);
    LCD_command(0x28);          // set 4-bit data, 2-line, 5x7 font
    LCD_command(0x06);          // move cursor right
    LCD_command(0x01);          // clear screen, move cursor to home
    LCD_command(0x0F);          // turn on display, cursor blinking
}

void PORTS_init(void) {
    SYSCTL->RCGCGPIO |= 0x01;   // enable clock to GPIOA
    SYSCTL->RCGCGPIO |= 0x10;   // enable clock to GPIOE
    SYSCTL->RCGCGPIO |= 0x08;   // enable clock to GPIOD
    SYSCTL->RCGCGPIO |= 0x04;   // enable clock to GPIOC

    // PORTA 5-2 LCD D7-D4
    GPIOA->AMSEL &= ~0x3C;      // turn off analog of PORTA 5-2
    GPIOA->DATA &= ~0x3C;       // PORTA 5-2 output low
    GPIOA->DIR |= 0x3C;         // PORTA 5-2 as GPIO output pins
    GPIOA->DEN |= 0x3C;         // PORTA 5-2 as digital pins

    // PORTE 0 for LCD R/S
    GPIOE->AMSEL &= ~0x01;      // disable analog
    GPIOE->DIR |= 0x01;         // set PORTE 0 as output for CS
    GPIOE->DEN |= 0x01;         // set PORTE 0 as digital pins
    GPIOE->DATA |= 0x01;        // set PORTE 0 idle high

    // PORTC 6 for LCD EN
    GPIOC->AMSEL &= ~0x40;      // disable analog
    GPIOC->DIR |= 0x40;         // set PORTC 6 as output for CS
    GPIOC->DEN |= 0x40;         // set PORTC 6 as digital pins
    GPIOC->DATA &= ~0x40;       // set PORTC 6 idle low

    GPIOD->AMSEL &= ~0x80;      // disable analog
    GPIOD->DIR |= 0x80;         // set PORTD 7 as output for CS
    GPIOD->DEN |= 0x80;         // set PORTD 7 as digital pins
    GPIOD->DATA |= 0x80;        // set PORTD 7 idle high
}