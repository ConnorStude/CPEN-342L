#include "TM4C123GH6PM.h"
//#include "DIP.h"
//#include "LCD.h"

void SSI1DAC_Init(void);
void SSI1DAC_Write(unsigned char data);
void hex2bcd(unsigned char x, char *str);

//****Part1***
int main(void) {
	SSI1DAC_Init();
	while(1){
		for (int i=0; i < 2048; i++)
		{
			unsigned int value = 2048-i;
			volatile unsigned char highDgt=0, lowDgt=0;
		
			GPIOD->DATA |= 0x02;
			GPIOD->DATA &= ~0x02;
			lowDgt = (unsigned char)value;
			highDgt = (unsigned char)(value>>8);
			SSI1DAC_Write(highDgt);
			SSI1DAC_Write(lowDgt);
		}
		for (int i=2048; i > 2048; i--)
		{
			unsigned int value = 2048-i;
			volatile unsigned char highDgt=0, lowDgt=0;
		
			GPIOD->DATA |= 0x02;
			GPIOD->DATA &= ~0x02;
			lowDgt = (unsigned char)value;
			highDgt = (unsigned char)(value>>8);
			SSI1DAC_Write(highDgt);
			SSI1DAC_Write(lowDgt);
		}
	}
}

//****Part2****
/*
int main(void)
{
	DIP_Init();
	LCD_Init();
	while(1){
		char volt = DIP_Read();
		char str[];
		hex2bcs(volt,str);
		LCD_command(1);
		LCD_Str(str);
		
		unsigned int value = 2048;
		volatile unsigned char highDgt=0, lowDgt=0;
		
		GPIOD->DATA |= 0x02;
		GPIOD->DATA &= ~0x02;
		lowDgt = (unsigned char)value*volt/16;
		highDgt = (unsigned char)(value>>8);
		SSI1DAC_Write(highDgt);
		SSI1DAC_Write(lowDgt);
	}
}

void hex2bcd(unsigned char x, char *str)
{
	unsigned char temp = x>>4;
	x = x&0x0F;
	char temp2[2] = {temp+0x30,x+0x30};
	str = temp2;
}

*/

void SSI1DAC_Init(void) {
	SYSCTL->RCGCSSI |= 2; /* enable clock to SSI1 */
	SYSCTL->RCGCGPIO |= 0x08; /* enable clock to GPIOD for SSI1*/
	while((SYSCTL->PRGPIO&0x008) == 0) {}; // ready?
	GPIOD->DEN |= 0x0B; /* make PD0,1,3 digital */
	GPIOD->AFSEL |= 0x09; /* enable alternate function for pin0,3 */
	GPIOD->PCTL &= ~0x0000F00F; /* assign pins to SSI1 */
	GPIOD->PCTL |= 0x00002002; /* assign pins to SSI1 */
	GPIOD->DIR |= 0x02; // set pin 1 as output
	SSI1->CR1 = 0; /* disable SSI and make it master */
	SSI1->CPSR = 10; /* prescaler divided by 10 */
	SSI1->CR0 = 0x0047; /* 5 MHz SSI clock, SPI mode, 8 bit data */
	SSI1->CR1 |= 2; /* enable SSI1 */
}

void SSI1DAC_Write(unsigned char data) {
	while((SSI1->SR & 2) == 0) {}; /* wait until FIFO not full */
	SSI1->DR = data; /* transmit high byte */
	while(SSI1->SR & 0x10); /* wait until transmit complete */
}
