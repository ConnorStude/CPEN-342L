#include "delayuS.h"
void delayuS(int n) {
    int i, j;
    for(i = 0 ; i< n; i++)
        for(j = 0; j < 6; j++)
            {}  /* do nothing for 1 ms */
}
