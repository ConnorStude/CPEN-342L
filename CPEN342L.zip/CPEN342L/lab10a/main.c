/****************************************************************************
Author: Jonathan Nastasi, Mark Madler
Lab 10: TM4C Based Ohmmeter
Date Created: April 12, 2023
Description: This program will display the resistor value 
placed in Rl by pressing the switch
Inputs: Comparator(PA7)(SW1(PF4)
Outputs: LCD
****************************************************************************/

#include "TM4C123GH6PM.h"
#include "DAConverter.h"
#include "LCD.h"
#include "stdio.h"
#include "delay.h"
#include "delayuS.h"
#define PF4 (* ((volatile uint32_t*) 0x40025040))

void PF4PA7_init(void);
	
int main (void)
{
	//initialization sequence:
	SSI1DAC_Init();
	LCD_init();
	PF4PA7_init();
	int pA;
	unsigned int value = 0;
	volatile unsigned char highDgt=0, lowDgt=0;
	while(1)
	{
		if (PF4==0) //when pressed SW1
		{			
				GPIOA->DATA &= ~0x80;
				//sweeps through voltage/current values on Rx
				for (int i=1; i<4096; i++){
					value = i;
					GPIOD->DATA |= 0x02;
					GPIOD->DATA &= ~0x02;
					
					//test DAC values and wait for circuit to adjust:
					lowDgt = (unsigned char)value;
					highDgt = (unsigned char)(value>>8);
					SSI1DAC_Write(highDgt);
					SSI1DAC_Write(lowDgt);  
					delayuS(100);
					pA = (GPIOA->DATA& 0x80);
					//when comparator goes high, save iteration number:
					if((pA &0x80)==0x80)
					{
						break;
					}
			}
			//calculation of R_L
			char str[15];
			int R = (250*8192)/(5*value);
			
			//write LCD
			if (value == 4095)
			{
				LCD_command(1);
				sprintf(str,"no Rload");
				LCD_Str(str);
			}
			//write LCD
			LCD_command(1);
			sprintf(str,"%d ohms", R);
			LCD_Str(str);
			delayMs(20);
		}
}
}
//initialize input pins for Switch and Comparator:
void PF4PA7_init(void)
{
	SYSCTL->RCGCGPIO |= 0x21;
	GPIOA->DIR &= ~0x80;
	GPIOF->DIR &= ~0x10;
	GPIOA->DEN |=0x80;
	GPIOF->DEN |= 0x10;
	GPIOA->DATA &= ~0x80;
	GPIOF->PUR = 0x10;
}
