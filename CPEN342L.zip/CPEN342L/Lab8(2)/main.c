/****************************************************************************
Author: Jonathan Nastasi, Mark Madler
Lab 6 - I/O Interfacing with the SSI
Date Created: February 25, 2023
Last Modified:
Description: This program adds 2 8-bit ports G and H using SSI bus
in order to control a bar graph LED using a Dip Switch
Inputs: Dip Switch
Outputs: Bar Graph LED
****************************************************************************/
#include "TM4C123GH6PM.h"
#include "SSI.h"

//void PB6(void);
	
int main(void){
	SSI1_Init();
	PortE_Init();
	uint8_t number;
	int counter = 0;
	
	//if (counter %2 == 0)
	
	//PB6();
	PWM_Init(10000, 5000); // 5 KHz, duty cycle 60%
	while(1){
	number = SSI1_Read();
	number = number & 0x03;
	if (number == 0)
		PWM_Duty(1);
	else if(number == 1)
		PWM_Duty(3030);
	else if(number == 2)
		PWM_Duty(6060);
	else if (number == 3)
		PWM_Duty(9090);
	counter++;
	
	}
}
