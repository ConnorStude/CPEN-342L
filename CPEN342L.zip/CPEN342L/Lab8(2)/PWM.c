#include "TM4C123GH6PM.h"
#include "PWM.h"

void PWM_Init(uint16_t period, uint16_t high){
SYSCTL->RCGCTIMER |= 0x08; // activate timer3
SYSCTL->RCGCGPIO |= 0x0002; // activate port B
while((SYSCTL->PRGPIO&0x0002) == 0){};// ready?
GPIOB->AFSEL |= 0x08; // enable alt funct on PB3
GPIOB->DEN |= 0x08; // enable digital I/O on PB3
GPIOB->PCTL = (GPIOB->PCTL&0xFFFF0FFF)+0x00007000;
TIMER3->CTL &= ~0x00000100; // disable timer0A during setup
TIMER3->CFG = 0x00000004; // configure for 16-bit timer mode
TIMER3->TBMR = 0x0000000A; // PWM and periodic mode
TIMER3->TBILR = period-1; // timer start value
TIMER3->TBMATCHR = period-high-1; // duty cycle = high/period
TIMER3->CTL |= 0x00000100; // enable timer0A 16-bit, PWM
}
// duty cycle = high/period
void PWM_Duty(uint16_t high){
TIMER3->TBMATCHR = TIMER3->TBILR-high;
}