#include "TM4C123GH6PM.h"

void SSI_Init(void);
uint8_t SSI_Read(void);
uint8_t SSI_Write(uint16_t code);
void delayMs(int n);