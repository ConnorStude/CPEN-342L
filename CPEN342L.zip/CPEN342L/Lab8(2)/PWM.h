void PWM_Init(uint16_t period, uint16_t high);
void PWM_Duty(uint16_t high);
