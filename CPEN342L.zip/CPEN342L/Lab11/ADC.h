uint16_t ADC1_InCh2(void);
void ADC1_InitCh2 (void);