#include "TM4C123GH6PM.h"
#include "DAConverter.h"
#include "LCD.h"
#include "stdio.h"
#include "delay.h"
#include "ADC.h"
//#include "delayuS.h"

void convertSamplesToPeriod(int samples, char *buffer);
	
int main (void){
	ADC1_InitCh2();
	LCD_init();
	LCD_command(1);
	float cntL1,cntL2,cntH1,cntH2;
	float high, low;
	float samples;
	int val= 0;
	int flag = 0;
	char str[15];
	while(1)
	{
		while(flag==0)
		{
				cntL1=0;
				cntH1 = 0;
				cntL2=0;
				cntH2 = 0;
				high = 0;
				low=0;
				val=ADC1_InCh2();
				if (val >= 2000)				//| ADC1_InCh2() <= (preVal-500))
				{
					high = val;
					while(val > 2000)
					{	if (val > high)
							high = val;
						val = ADC1_InCh2();
						cntH1++;}
					while(val <=2000)
					{	if (val > high)
							low = val;
						val = ADC1_InCh2();
						cntL1++;}
					while(val >2000)
					{	if (val > high)
							high = val;
						val = ADC1_InCh2();
						cntH2++;}
					while(val <=2000)
					{	if (val > high)
							low = val;
						val = ADC1_InCh2();
						cntL2++;}
				}
				else
				{
					low = val;
					while(val <=2000)
					{	if (val > high)
							low = val;
						val = ADC1_InCh2();
						cntL1++;}
					while(val >2000)
					{	if (val > high)
							high = val;
						
						val = ADC1_InCh2();
						cntH1++;}
					while(val <=2000)
					{	if (val > high)
							low = val;
						val = ADC1_InCh2();
						cntL2++;}
					while(val > 2000)
					{	if (val > high)
							high = val;
						val = ADC1_InCh2();
						cntH2++;}
				}
			
			flag=0;
				high = (high * 3.3) /4095;
				low = (low * 3.3) /4095;
			samples = cntL2+cntH2;
			float period = ((samples/250000)*1.45)*1000000;
			float frequency = 1000000/period;
			float duty = (cntH2*100)/(cntH2+cntL2);
			LCD_command(1);
			sprintf(str,"%2.2f us", period),
			LCD_Str(str);
				delayMs(500);
				LCD_command(1);
			sprintf(str,"%2.2f Max Volt", high),
			LCD_Str(str);
				delayMs(500);
				LCD_command(1);
			sprintf(str,"%2.2f Low Volt", low),
			LCD_Str(str);
				delayMs(500);
				LCD_command(1);
			sprintf(str,"%2.2f Hz", frequency),
			LCD_Str(str);
				delayMs(500);
				LCD_command(1);
			sprintf(str,"%2.2f %%Duty", duty),
			LCD_Str(str);
				delayMs(500);
		}
	}
}

void convertSamplesToPeriod(int samples, char *buffer){
	int period = ((samples/250000)/2)*1000000; //250k samples/sec, period in us
	char str[15];
	LCD_command(1);
	sprintf(buffer,"%d us", period),
	LCD_Str(buffer);
}