#include "TM4C123GH6PM.h"
#include "ADC.h"

void ADC1_InitCh2 (void){
	volatile uint32_t delay;
	SYSCTL->RCGCADC |= 0x02; // 1) activate ADC1
	SYSCTL->RCGCGPIO |= 0x10; // 1) activate clock for Port E
	delay = SYSCTL->RCGCGPIO;
	GPIOE->DIR &= ~0x02; // make PE1 
	GPIOE->AFSEL |= 0x02; // enable alternate function on PE1
	GPIOE->DEN &= ~0x02; // disable digital I/O on PE1
	GPIOE->AMSEL |= 0x02; // enable analog functionality on PE1
	ADC1->PC = 0x03; // 2) configure for 250K samples/sec
	ADC1->SSPRI = 0x3210; // 3) Sequencer 3 is lowest priority
	ADC1->ACTSS &= ~0x0008; // 5) disable sample sequencer 3
	ADC1->EMUX &= ~0xF000; // 6) seq3 is software trigger
	ADC1->SSMUX3 = 0x0002; // 7) set channels for SS3
	ADC1->SSCTL3 = 0x0006; // 8) set IE0 END0
	ADC1->IM &= ~0x0008; // 9) disable SS3 interrupts
	ADC1->ACTSS |= 0x0008; // 10) enable sample sequencer 3
}
uint16_t ADC1_InCh2(void){
	ADC1->PSSI = 0x0008; // initiate SS3 � software trigger
	while((ADC1->RIS&0x08)==0){}; // wait for conversion done
	ADC1->ISC = 0x0008; // acknowledge completion
	return(ADC1->SSFIFO3&0xFFF);
}