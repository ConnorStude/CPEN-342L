#include "TM4C123GH6PM.h"
/****************************************************************************
Author: Yanqing Ji
Lab 1: GPIO and C Language
Date Created: January 8, 2019
Last Modified:
Description: this program will display RGB LED according to the value read
from SW1 and SW2.
If both switches SW1 and SW2 are pressed, the LED should be blue
If just SW1 switch is pressed, the LED should be red
If just SW2 switch is pressed, the LED should be green
If neither SW1 or SW2 is pressed, the LED should be off
Inputs: SW1 and SW2
Outputs: RGB LED
****************************************************************************/

#define GPIO_PORTF_DATA_R (*((volatile uint32_t *)0x400253FC))
#define GPIO_PORTF_DIR_R (*((volatile uint32_t *)0x40025400))
#define GPIO_PORTF_AFSEL_R (*((volatile uint32_t *)0x40025420))
#define GPIO_PORTF_DEN_R (*((volatile uint32_t *)0x4002551C))
#define GPIO_PORTF_CR_R (*((volatile uint32_t *)0x40025524))
#define GPIO_PORTF_LOCK_R (*((volatile uint32_t *)0x40025520))
#define GPIO_PORTF_AMSEL_R (*((volatile uint32_t *)0x40025528))
#define GPIO_PORTF_PCTL_R (*((volatile uint32_t *)0x4002552C))
#define SYSCTL_RCGCGPIO_R (*((volatile uint32_t *)0x400FE608))
#define SYSCTL_PRGPIO_R (*((volatile uint32_t *)0x400FEA08))
#define PF04 (*((volatile uint32_t *)0x40025044 //input
#define PF123 (*((volatile uint32_t *)0x40025038 //output
	
	void PortF_Init(void);
	void Delay(void);

int main(){
	PortF_Init();
	GPIO_PORTF_DATA_R = 0x02;
	Delay();
	//PF123 = 0X00;
	
	
	return 0;
}
void PortF_Init(void){
SYSCTL_RCGCGPIO_R |= 0x20; // 1) activate clock for Port D; bit 0:A, 1:B, � 5:F
while ((SYSCTL_PRGPIO_R&0x10) == 0) {}; // ready?
GPIO_PORTF_LOCK_R = 0X4C4F434B; // 2) unlock GPIO Port D, magic number
GPIO_PORTF_CR_R = 0xFF; // allow changes to PD7
//GPIO_PORTF_AMSEL_R = 0x00; // 3) disable analog on PD
//GPIO_PORTF_PCTL_R = 0x00000000; // 4) PTCL GPIO on PD7-0
GPIO_PORTF_DIR_R |= 0x0E; // 5) PD7-4 in, PD3-0 out
GPIO_PORTF_DIR_R &= ~0x11;
//GPIO_PORTF_AFSEL_R = 0x00; // 6) disable alt funct on PD7-0
GPIO_PORTF_DEN_R |= 0x1F; // 7) enable digital I/O on PD7-0
}

void Delay(void){
unsigned long volatile time;
 time = 727240*200/91; // 0.1sec
 while(time){
time--;
 }
}

/*void LEDs(void){
	unsigned long volatile temp = PF04;
	if (PF04 == 0x00){
		PF123=0x00;}
	else if(PF04 == 0x01){
		PF123 = 0x08;}
	else if(PF04 == 0x10){
		PF123 = 0x10;}
	else if(PF04 == 0x11){
		PF123 = 0x0E;}
}*/