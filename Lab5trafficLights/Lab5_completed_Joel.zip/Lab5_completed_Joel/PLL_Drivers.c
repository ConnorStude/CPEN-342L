#include <stdint.h>
#include "tm4c123gh6pm.h"

void PLL_Init(void) {
    SYSCTL->RCC2 |= 0x80000000;
    SYSCTL->RCC2 |= 0x00000800;
    SYSCTL->RCC = (SYSCTL->RCC &= 0x000007C0) + 0x00000540; //16MHz
    SYSCTL->RCC2 &= 0x00000070;
    SYSCTL->RCC2 &= 0x00002000;
    SYSCTL->RCC2 = (SYSCTL->RCC2&~0x1FC00000)+(39<<22);
    while ((SYSCTL->RIS&0x00000040)==0){};
    SYSCTL->RCC2 &= ~0x00000800;
}

