#include <stdint.h>
#include "tm4c123gh6pm.h"

void TrafficLight_Init(void) {
    SYSCTL->RCGCGPIO |= 0x02;
    while ((SYSCTL->PRGPIO & 0x02) == 0){}; // wait until port B is ready
    GPIOB->DIR |= 0x3F; // set PB0-PB5 as Output
    GPIOB->DEN |= 0x3F; // enable I/O for PB0-PB5
}

//set colors
void setGR(void) {
    GPIOB->DATA |= 0x0C;
}

void setYR(void) {
    GPIOB->DATA |= 0x0A;
}

void setRR(void) {
    GPIOB->DATA |= 0x09;
}

void setRG(void) {
    GPIOB->DATA |= 0x21;
}

void setRY(void) {
    GPIOB->DATA |= 0x11;
}

void ClearTrafficLight(void) {
    GPIOB->DATA = 0x00;
}
