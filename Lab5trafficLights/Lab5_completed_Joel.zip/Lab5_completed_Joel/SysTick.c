#include <stdint.h>
#include "tm4c123gh6pm.h"
#include "SysTick.h"
#include "TrafficLightDriver.h"

//int ix = 0; // index of digits
int state = 0; //count the number of interrupts
//int counter = 0;

//uint8_t time[6] = {10,2,1,10,2,1};
uint8_t pattern[6] = {0x0C,0x0A,0x09,0x21,0x11,0x09};

void SysTick_Init(uint32_t period) {
	SysTick->CTRL = 0; // 1) disable SysTick during setup
	SysTick->LOAD = period - 1; // 2) reload value
	SysTick->VAL = 0; // 3) any write to CURRENT clears it
	SysTick->CTRL = 0x00000007; // 4) enable SysTick with core clock and
	//interrupts (local)
	__enable_irq(); // enable interrupts (global)
}
void SysTick_Handler(void) { // SysTick interrupt handler
	if (state < 10) {
		GPIOB->DATA = ~pattern[0];
	} else if (state < 12) {
		GPIOB->DATA = ~pattern[1];
	} else if (state < 13) {
		GPIOB->DATA = ~pattern[2];
	} else if (state < 23) {
		GPIOB->DATA = ~pattern[3];
	} else if (state < 25) {
		GPIOB->DATA = ~pattern[4];
	} else if (state < 26) {
		GPIOB->DATA = ~pattern[5];
	} else {
		state = 0;
	}
	state++;
}
