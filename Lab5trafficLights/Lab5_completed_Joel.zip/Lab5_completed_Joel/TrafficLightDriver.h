void TrafficLight_Init(void);
void setGR(void);
void setYR(void);
void setRR(void);
void setRG(void);
void setRY(void);
void ClearTrafficLight(void);
