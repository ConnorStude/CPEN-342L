/****************************************************************************
Author: Joel George Vincent
Lab 5 - Periodic Interrupt-Driven Traffic Lights
Date Created: February 21, 2024
Last Modified: February 21, 2024
Description: Design a traffic light controller that sequences through different traffic light states as
described in Assignment#4. The lights are assumed to be at a four-way intersection with
one street going north-south and the other road going east-west.
Inputs: No inputs, SysTick handler should take care of everything.
Outputs: Green, Yellow, and Red LED's displaying in a certain order
****************************************************************************/

#include "tm4c123gh6pm.h"
#include "PLL_Drivers.h"
#include "TrafficLightDriver.h"
#include "SysTick.h"
#include "delay.h"

int main(void) {
	uint32_t period = 10000000;
	
	PLL_Init();
	TrafficLight_Init();
	SysTick_Init(period);
	
	while(1){};
}